import React, { useState, useRef } from 'react';
import { Chat } from '@google/genai';
import Header from './components/Header';
import Introduction from './components/Introduction';
import SpecializationCard from './components/SpecializationCard';
import ConsultationForm from './components/ConsultationForm';
import Recommendation from './components/Recommendation';
import Loader from './components/Loader';
import LiveChat from './components/LiveChat';
import { getCareerAdvice, buildInitialPrompt, createChatSession } from './services/geminiService';
import type { UserProfile, ChatMessage } from './types';
import { Specialization } from './types';

const FinanceIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
    </svg>
);

const MarketingIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M7 12l3-3 3 3 4-4M8 21l4-4 4 4M3 4h18M4 4h16v12a1 1 0 01-1 1H5a1 1 0 01-1-1V4z" />
    </svg>
);

const AccountingIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
    </svg>
);

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);
  const [recommendation, setRecommendation] = useState<string | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [error, setError] = useState<string | null>(null);

  const recommendationRef = useRef<HTMLDivElement>(null);
  const chatRef = useRef<Chat | null>(null);

  const handleFormSubmit = async (profile: UserProfile) => {
    setIsLoading(true);
    setRecommendation(null);
    setError(null);
    setChatMessages([]);

    setTimeout(() => {
        recommendationRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);

    try {
      const result = await getCareerAdvice(profile);
      setRecommendation(result);

      // Initialize chat
      const initialPrompt = buildInitialPrompt(profile);
      const initialHistory = [
        { role: 'user', parts: [{ text: initialPrompt }] },
        { role: 'model', parts: [{ text: result }] },
      ];
      chatRef.current = createChatSession(initialHistory);

      // A more user-friendly representation for the chat UI
      setChatMessages([
          { role: 'user', content: "Based on my profile, what specialization do you recommend for me?" },
          { role: 'model', content: result }
      ]);
      
    } catch (err) {
      setError("An unexpected error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async (message: string) => {
      if (!chatRef.current) return;

      setChatMessages(prev => [...prev, { role: 'user', content: message }]);
      setIsChatLoading(true);

      try {
          const stream = await chatRef.current.sendMessageStream({ message });
          let modelResponse = '';
          // Add a placeholder for the model's response
          setChatMessages(prev => [...prev, { role: 'model', content: '' }]);

          for await (const chunk of stream) {
              modelResponse += chunk.text;
              setChatMessages(prev => {
                  const newMessages = [...prev];
                  newMessages[newMessages.length - 1].content = modelResponse;
                  return newMessages;
              });
          }
      } catch (err) {
          console.error("Chat error:", err);
          setChatMessages(prev => [...prev, { role: 'model', content: "Sorry, I encountered an error. Please try again." }]);
      } finally {
          setIsChatLoading(false);
      }
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <Header />
      <main className="max-w-4xl mx-auto p-4 md:p-8 space-y-8">
        <Introduction />
        
        <div className="grid md:grid-cols-3 gap-6">
          <SpecializationCard 
            specialization={Specialization.Finance}
            icon={<FinanceIcon />}
            description="Focuses on managing money, investments, and assets to create and sustain economic value."
          />
          <SpecializationCard 
            specialization={Specialization.Marketing}
            icon={<MarketingIcon />}
            description="Involves creating, communicating, and delivering value to customers and managing customer relationships."
          />
          <SpecializationCard 
            specialization={Specialization.Accounting}
            icon={<AccountingIcon />}
            description="The systematic recording, reporting, and analysis of financial transactions of a business."
          />
        </div>
        
        {!recommendation && <ConsultationForm onSubmit={handleFormSubmit} isLoading={isLoading} />}
        
        <div ref={recommendationRef} className="pt-4">
          {isLoading && <Loader />}
          {error && <p className="text-red-500 text-center">{error}</p>}
          {recommendation && <Recommendation text={recommendation} />}
          {chatMessages.length > 0 && (
            <LiveChat 
                messages={chatMessages}
                onSendMessage={handleSendMessage}
                isLoading={isChatLoading}
            />
          )}
        </div>
      </main>
      <footer className="text-center py-6 text-gray-500">
        <p>&copy; {new Date().getFullYear()} Commerce Career Compass. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default App;
