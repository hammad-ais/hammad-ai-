import React, { useState } from 'react';
import type { UserProfile } from '../types';

interface ConsultationFormProps {
  onSubmit: (profile: UserProfile) => void;
  isLoading: boolean;
}

const RadioOption: React.FC<{
  name: string;
  value: string;
  label: string;
  checked: boolean;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}> = ({ name, value, label, checked, onChange }) => (
  <label className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-blue-50 cursor-pointer transition-colors">
    <input
      type="radio"
      name={name}
      value={value}
      checked={checked}
      onChange={onChange}
      className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
      aria-label={label}
    />
    <span className="text-gray-700">{label}</span>
  </label>
);

const ConsultationForm: React.FC<ConsultationFormProps> = ({ onSubmit, isLoading }) => {
  const [profile, setProfile] = useState<UserProfile>({
    interest: '',
    skill: '',
    workStyle: '',
    ambition: '',
    mbti: {
        ei: '',
        sn: '',
        tf: '',
        jp: '',
    }
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    if (['ei', 'sn', 'tf', 'jp'].includes(name)) {
        setProfile(prev => ({
            ...prev,
            mbti: { ...prev.mbti, [name]: value }
        }));
    } else {
        setProfile({ ...profile, [name]: value });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isFormComplete) {
      onSubmit(profile);
    } else {
      alert('Please fill out all required fields.');
    }
  };

  const isFormComplete = !!(profile.interest && profile.skill && profile.workStyle && profile.mbti.ei && profile.mbti.sn && profile.mbti.tf && profile.mbti.jp);

  return (
    <div className="bg-white p-8 rounded-lg shadow-md border border-gray-200">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Tell Me About Yourself</h2>
      <form onSubmit={handleSubmit} className="space-y-8">
        <div>
          <label className="block text-lg font-semibold text-gray-700 mb-3">Which activity sounds most engaging to you?</label>
          <div className="space-y-3">
            <RadioOption name="interest" value="Analyzing data and financial markets to make strategic decisions." label="Analyzing data and financial markets to make strategic decisions." checked={profile.interest === "Analyzing data and financial markets to make strategic decisions."} onChange={handleChange} />
            <RadioOption name="interest" value="Understanding customer needs and crafting creative campaigns." label="Understanding customer needs and crafting creative campaigns." checked={profile.interest === "Understanding customer needs and crafting creative campaigns."} onChange={handleChange} />
            <RadioOption name="interest" value="Ensuring financial accuracy, maintaining order, and upholding regulations." label="Ensuring financial accuracy, maintaining order, and upholding regulations." checked={profile.interest === "Ensuring financial accuracy, maintaining order, and upholding regulations."} onChange={handleChange} />
          </div>
        </div>

        <div>
          <label className="block text-lg font-semibold text-gray-700 mb-3">What is your strongest skill?</label>
          <div className="space-y-3">
            <RadioOption name="skill" value="Quantitative analysis and logical reasoning." label="Quantitative analysis and logical reasoning." checked={profile.skill === "Quantitative analysis and logical reasoning."} onChange={handleChange} />
            <RadioOption name="skill" value="Communication, persuasion, and creativity." label="Communication, persuasion, and creativity." checked={profile.skill === "Communication, persuasion, and creativity."} onChange={handleChange} />
            <RadioOption name="skill" value="Attention to detail, organization, and ethical judgment." label="Attention to detail, organization, and ethical judgment." checked={profile.skill === "Attention to detail, organization, and ethical judgment."} onChange={handleChange} />
          </div>
        </div>

        <div>
          <label className="block text-lg font-semibold text-gray-700 mb-3">What's your ideal work environment?</label>
          <div className="space-y-3">
            <RadioOption name="workStyle" value="Fast-paced, competitive, and high-stakes." label="Fast-paced, competitive, and high-stakes." checked={profile.workStyle === "Fast-paced, competitive, and high-stakes."} onChange={handleChange} />
            <RadioOption name="workStyle" value="Dynamic, collaborative, and people-oriented." label="Dynamic, collaborative, and people-oriented." checked={profile.workStyle === "Dynamic, collaborative, and people-oriented."} onChange={handleChange} />
            <RadioOption name="workStyle" value="Structured, precise, and methodical." label="Structured, precise, and methodical." checked={profile.workStyle === "Structured, precise, and methodical."} onChange={handleChange} />
          </div>
        </div>
        
        <fieldset>
          <legend className="block text-xl font-bold text-gray-800 mb-4 border-b pb-2">Personality Insights</legend>
          <div className="space-y-6">
            <div>
              <label className="block text-lg font-semibold text-gray-700 mb-3">How do you prefer to focus your energy?</label>
              <div className="space-y-3">
                <RadioOption name="ei" value="Extraversion" label="I am outgoing and gain energy from social interaction." checked={profile.mbti.ei === "Extraversion"} onChange={handleChange} />
                <RadioOption name="ei" value="Introversion" label="I am reserved and gain energy from spending time alone." checked={profile.mbti.ei === "Introversion"} onChange={handleChange} />
              </div>
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-700 mb-3">How do you prefer to process information?</label>
              <div className="space-y-3">
                <RadioOption name="sn" value="Sensing" label="I focus on concrete facts and details that I can see and touch." checked={profile.mbti.sn === "Sensing"} onChange={handleChange} />
                <RadioOption name="sn" value="Intuition" label="I focus on patterns, possibilities, and abstract concepts." checked={profile.mbti.sn === "Intuition"} onChange={handleChange} />
              </div>
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-700 mb-3">How do you prefer to make decisions?</label>
              <div className="space-y-3">
                <RadioOption name="tf" value="Thinking" label="I make decisions based on logic, objectivity, and analysis." checked={profile.mbti.tf === "Thinking"} onChange={handleChange} />
                <RadioOption name="tf" value="Feeling" label="I make decisions based on my values and how they impact others." checked={profile.mbti.tf === "Feeling"} onChange={handleChange} />
              </div>
            </div>

            <div>
              <label className="block text-lg font-semibold text-gray-700 mb-3">How do you prefer to live your outer life?</label>
              <div className="space-y-3">
                <RadioOption name="jp" value="Judging" label="I prefer a planned, organized, and structured approach to life." checked={profile.mbti.jp === "Judging"} onChange={handleChange} />
                <RadioOption name="jp" value="Perceiving" label="I prefer a spontaneous, flexible, and adaptable approach to life." checked={profile.mbti.jp === "Perceiving"} onChange={handleChange} />
              </div>
            </div>
          </div>
        </fieldset>

        <div>
          <label htmlFor="ambition" className="block text-lg font-semibold text-gray-700 mb-2">Briefly, what is your primary career ambition or goal? (optional)</label>
          <textarea
            id="ambition"
            name="ambition"
            value={profile.ambition}
            onChange={handleChange}
            rows={3}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-shadow"
            placeholder="e.g., 'I want to lead a company's financial strategy' or 'I want to build a memorable brand'."
          />
        </div>

        <button
          type="submit"
          disabled={isLoading || !isFormComplete}
          className="w-full bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 disabled:bg-blue-300 disabled:cursor-not-allowed transition-all flex items-center justify-center space-x-2 text-lg"
        >
          {isLoading ? (
             <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
          ) : null}
          <span>{isLoading ? 'Analyzing...' : 'Get My Recommendation'}</span>
        </button>
      </form>
    </div>
  );
};

export default ConsultationForm;
