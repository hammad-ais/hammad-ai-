
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="text-center py-8 md:py-12 bg-white shadow-sm">
      <h1 className="text-4xl md:text-5xl font-bold text-gray-800">
        Commerce Career <span className="text-blue-600">Compass</span>
      </h1>
      <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
        Your Personal AI Career Counselor for Commerce Specializations
      </p>
    </header>
  );
};

export default Header;
