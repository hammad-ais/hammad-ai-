import React from 'react';

const Introduction: React.FC = () => {
  return (
    <div className="bg-white p-8 rounded-lg shadow-md flex items-center space-x-6 border border-gray-200">
      <img
        src="https://picsum.photos/id/1005/150/150"
        alt="Hammad Ai, AI Career Consultant"
        className="w-24 h-24 md:w-32 md:h-32 rounded-full object-cover border-4 border-blue-200"
      />
      <div>
        <h2 className="text-2xl font-bold text-gray-800">Meet Hammad Ai</h2>
        <p className="mt-2 text-gray-600">
          With three decades of experience in career counseling, I'm here to analyze your unique strengths and aspirations. My purpose is to chart the best course for your commerce career. Let's begin.
        </p>
      </div>
    </div>
  );
};

export default Introduction;
