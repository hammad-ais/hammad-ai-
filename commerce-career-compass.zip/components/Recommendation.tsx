
import React, { useMemo } from 'react';
import type { ParsedRecommendation } from '../types';

interface RecommendationProps {
  text: string;
}

function parseRecommendation(text: string): ParsedRecommendation {
  const sections: { [key: string]: string } = {
    recommendation: '',
    rationale: '',
    pathways: '',
    skills: '',
    encouragement: '',
  };

  const lines = text.split('\n').filter(line => line.trim() !== '');

  let currentSection: keyof typeof sections | null = null;

  for (const line of lines) {
    if (line.startsWith('### TOP RECOMMENDATION')) {
      currentSection = 'recommendation';
    } else if (line.startsWith('### PERSONALIZED RATIONALE')) {
      currentSection = 'rationale';
    } else if (line.startsWith('### CAREER PATHWAYS')) {
      currentSection = 'pathways';
    } else if (line.startsWith('### SKILLS TO CULTIVATE')) {
      currentSection = 'skills';
    } else if (line.startsWith('### A WORD OF ENCOURAGEMENT')) {
      currentSection = 'encouragement';
    } else if (currentSection) {
      sections[currentSection] += line + '\n';
    }
  }

  const parseList = (listText: string) => listText.split('\n').map(item => item.trim().replace(/^- \s*/, '')).filter(Boolean);

  return {
    recommendation: sections.recommendation.trim(),
    rationale: sections.rationale.trim(),
    pathways: parseList(sections.pathways),
    skills: parseList(sections.skills),
    encouragement: sections.encouragement.trim(),
  };
}

const Recommendation: React.FC<RecommendationProps> = ({ text }) => {
  const parsed = useMemo(() => parseRecommendation(text), [text]);

  if (!parsed.recommendation) {
    return (
      <div className="bg-white p-8 rounded-lg shadow-md border border-red-200">
        <h2 className="text-2xl font-bold text-red-700 mb-4">Analysis Error</h2>
        <p className="text-gray-600">{text || "Could not parse the recommendation. The AI may have returned an unexpected format."}</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-8 rounded-lg shadow-lg border border-gray-200 animate-fade-in">
      <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">Your Personalized Recommendation</h2>
      
      <div className="mb-6 p-6 bg-blue-50 border-l-4 border-blue-500 rounded-r-lg">
        <h3 className="text-lg font-semibold text-blue-800 uppercase tracking-wider">Top Recommendation</h3>
        <p className="text-2xl font-bold text-blue-600 mt-2">{parsed.recommendation}</p>
      </div>

      <div className="space-y-6">
        <div>
          <h3 className="text-xl font-semibold text-gray-700 mb-2">Personalized Rationale</h3>
          <p className="text-gray-600 leading-relaxed">{parsed.rationale}</p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">Potential Career Pathways</h3>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              {parsed.pathways.map((path, i) => <li key={i}>{path}</li>)}
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">Skills to Cultivate</h3>
            <ul className="list-disc list-inside space-y-2 text-gray-600">
              {parsed.skills.map((skill, i) => <li key={i}>{skill}</li>)}
            </ul>
          </div>
        </div>
        
        <div className="pt-4 border-t border-gray-200">
           <h3 className="text-xl font-semibold text-gray-700 mb-2">A Word of Encouragement</h3>
          <p className="text-gray-600 italic">"{parsed.encouragement}"</p>
        </div>
      </div>
    </div>
  );
};

export default Recommendation;
