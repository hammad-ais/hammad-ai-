import React from 'react';
// FIX: Changed import from 'import type' to a value import for the Specialization enum.
import { Specialization } from '../types';

interface SpecializationCardProps {
  specialization: Specialization;
  icon: React.ReactNode;
  description: string;
}

const SpecializationCard: React.FC<SpecializationCardProps> = ({ specialization, icon, description }) => {
  const colors = {
    [Specialization.Finance]: 'border-blue-500',
    [Specialization.Marketing]: 'border-purple-500',
    [Specialization.Accounting]: 'border-green-500',
  };

  return (
    <div className={`bg-white p-6 rounded-lg shadow-sm border-t-4 ${colors[specialization]} transition-transform transform hover:-translate-y-1`}>
      <div className="flex items-center space-x-4">
        <div className="text-3xl">{icon}</div>
        <h3 className="text-xl font-semibold text-gray-800">{specialization}</h3>
      </div>
      <p className="mt-4 text-gray-600">
        {description}
      </p>
    </div>
  );
};

export default SpecializationCard;