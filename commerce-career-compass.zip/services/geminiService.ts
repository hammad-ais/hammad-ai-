import { GoogleGenAI, Chat } from "@google/genai";
import type { UserProfile } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const systemInstruction = `You are 'Hammad Ai', a world-class career consultant with over 30 years of experience. Your specialty is guiding commerce students towards their ideal specialization. Your tone is wise, encouraging, and professional. You provide clear, actionable advice.`;

export function buildInitialPrompt(profile: UserProfile): string {
    return `
    A commerce student is seeking your guidance on choosing a specialization between Finance, Marketing, and Accounting.

    Here is the student's profile:
    - Enjoys activities related to: ${profile.interest}
    - Their strongest skill is: ${profile.skill}
    - Their preferred work style is: ${profile.workStyle}
    - Their ambition or goal is: ${profile.ambition || 'Not specified'}
    - Their personality profile (MBTI-inspired) suggests they lean towards:
      - Energy & Focus: ${profile.mbti.ei}
      - Information Processing: ${profile.mbti.sn}
      - Decision Making: ${profile.mbti.tf}
      - Lifestyle & Work Approach: ${profile.mbti.jp}

    Based on this complete profile, provide a comprehensive career consultation. Your response must be in Markdown and structured exactly as follows, using these exact headings:

    ### TOP RECOMMENDATION
    State clearly which specialization (Finance, Marketing, or Accounting) you recommend.

    ### PERSONALIZED RATIONALE
    In-depth explanation of *why* you recommend this path, directly linking your reasoning to the student's stated interests, skills, work style, and personality insights.

    ### CAREER PATHWAYS
    List 3-5 potential career roles within this specialization as a bulleted list.

    ### SKILLS TO CULTIVATE
    Suggest 3 key skills they should focus on developing to excel in this field as a bulleted list.

    ### A WORD OF ENCOURAGEMENT
    A short, motivational closing statement.

    Make a definitive choice based on the profile provided. Do not suggest more than one specialization.
  `;
}

export async function getCareerAdvice(profile: UserProfile): Promise<string> {
  const prompt = buildInitialPrompt(profile);

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            systemInstruction: systemInstruction,
        }
    });
    return response.text;
  } catch (error) {
    console.error("Error fetching career advice:", error);
    return "I'm sorry, but I'm having trouble connecting at the moment. Please check your connection or API key and try again later.";
  }
}

// The history type is complex, so we use 'any' for simplicity here, but in a larger app, you'd want to use the specific types from the SDK.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function createChatSession(history: any[]): Chat {
    return ai.chats.create({
        model: 'gemini-2.5-flash',
        history: history,
        config: {
            systemInstruction: systemInstruction,
        }
    });
}
