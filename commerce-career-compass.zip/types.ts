export enum Specialization {
  Finance = 'Finance',
  Marketing = 'Marketing',
  Accounting = 'Accounting',
}

export interface UserProfile {
  interest: string;
  skill: string;
  workStyle: string;
  ambition: string;
  mbti: {
    ei: string; // Extraversion / Introversion
    sn: string; // Sensing / Intuition
    tf: string; // Thinking / Feeling
    jp: string; // Judging / Perceiving
  };
}

export interface ParsedRecommendation {
  recommendation: string;
  rationale: string;
  pathways: string[];
  skills: string[];
  encouragement: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
}
